"""
Architectural Floor Plan -> 3D Visualization System (Blender 3.x / 4.x)

HOW TO RUN
  Blender > Scripting tab > Open this file > Run Script
  (or: blender --background --python floorplan_to_3d.py)

PIPELINE (this is the "conversion"):
  1. Floor plan data  : walls (2D line segments), openings (doors/windows), rooms (rectangles)
  2. 2D plan          : walls drawn as flat footprints (height ~0) + coloured rooms + labels
  3. 3D model         : the SAME wall footprints extruded to wall height
  4. Openings         : cutter boxes + Boolean DIFFERENCE modifier -> real door/window holes
  5. Views            : Orthographic (top plan, isometric) + Perspective cameras
"""
import bpy, math
from mathutils import Vector

# ----------------------------------------------------------------------------
# 1. FLOOR PLAN DATA (metres).  Edit this to convert your own plan.
# ----------------------------------------------------------------------------
WALL_T = 0.20          # wall thickness
WALL_H = 3.00          # wall height (3D)
OFFSET_2D = Vector((-16, 0, 0))   # where the 2D plan is placed beside the 3D model

# walls: (x1, y1, x2, y2)  -- axis-aligned segments
WALLS = [
    (0, 0, 10, 0), (10, 0, 10, 8), (10, 8, 0, 8), (0, 8, 0, 0),   # outer
    (6, 0, 6, 5),                                                  # living | kitchen
    (0, 5, 10, 5),                                                 # front | back rooms
    (5, 5, 5, 8),                                                  # bedroom | bathroom
]

# openings: (x, y, width, sill_height, top_height, orientation 'H' or 'V', kind)
#   'H' = opening sits in a wall running along X ; 'V' = wall running along Y
OPENINGS = [
    (3.0, 0.0, 1.0, 0.0, 2.1, 'H', 'door'),     # main entrance
    (8.0, 0.0, 1.5, 0.9, 2.1, 'H', 'window'),
    (0.0, 2.5, 1.5, 0.9, 2.1, 'V', 'window'),
    (10.0, 2.5, 1.5, 0.9, 2.1, 'V', 'window'),
    (6.0, 2.5, 1.2, 0.0, 2.1, 'V', 'door'),     # living -> kitchen
    (3.0, 5.0, 0.9, 0.0, 2.1, 'H', 'door'),     # living -> bedroom
    (8.0, 5.0, 0.9, 0.0, 2.1, 'H', 'door'),     # kitchen -> bathroom
    (2.5, 8.0, 1.5, 0.9, 2.1, 'H', 'window'),
    (7.5, 8.0, 1.0, 0.9, 2.1, 'H', 'window'),
]

# rooms: (name, x1, y1, x2, y2, RGBA colour)
ROOMS = [
    ("LIVING ROOM", 0, 0, 6, 5, (0.80, 0.90, 1.00, 1)),
    ("KITCHEN",     6, 0, 10, 5, (1.00, 0.92, 0.70, 1)),
    ("BEDROOM",     0, 5, 5, 8, (0.85, 1.00, 0.85, 1)),
    ("BATHROOM",    5, 5, 10, 8, (0.95, 0.85, 1.00, 1)),
]

# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def clear_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete()
    for c in list(bpy.data.collections):
        bpy.data.collections.remove(c)

def new_collection(name):
    c = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(c)
    return c

def move_to(obj, coll):
    for c in obj.users_collection:
        c.objects.unlink(obj)
    coll.objects.link(obj)

def make_material(name, rgba):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    m.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = rgba
    m.diffuse_color = rgba
    return m

def box(name, center, size, coll, mat=None):
    """Cuboid centred at `center` with full dimensions `size`."""
    bpy.ops.mesh.primitive_cube_add(location=center)
    o = bpy.context.active_object
    o.name = name
    o.scale = (size[0] / 2, size[1] / 2, size[2] / 2)
    bpy.ops.object.transform_apply(scale=True)
    move_to(o, coll)
    if mat:
        o.data.materials.append(mat)
    return o

def boolean_cut(target, cutter):
    mod = target.modifiers.new("cut", 'BOOLEAN')
    mod.operation = 'DIFFERENCE'
    mod.object = cutter
    bpy.context.view_layer.objects.active = target
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter, do_unlink=True)

def wall_boxes(prefix, height, z_base, origin, coll, mat):
    """Steps 2 & 3: turn each 2D wall segment into a box (flat for 2D, tall for 3D)."""
    walls = []
    for i, (x1, y1, x2, y2) in enumerate(WALLS):
        horizontal = abs(y2 - y1) < 1e-6
        length = abs(x2 - x1) if horizontal else abs(y2 - y1)
        length += WALL_T                      # overlap corners so joints are closed
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        size = (length, WALL_T, height) if horizontal else (WALL_T, length, height)
        c = Vector((cx, cy, z_base + height / 2)) + origin
        walls.append(box(f"{prefix}_wall_{i}", c, size, coll, mat))
    return walls

def cut_openings(walls, origin, flat):
    """Step 4: boolean-cut doors/windows through whichever wall they touch."""
    for j, (x, y, w, sill, top, orient, kind) in enumerate(OPENINGS):
        z0, z1 = (0.0, 0.05) if flat else (sill, top)
        size = (w, WALL_T * 3, z1 - z0) if orient == 'H' else (WALL_T * 3, w, z1 - z0)
        centre = Vector((x, y, (z0 + z1) / 2)) + origin
        for wall in walls:
            # cut only the wall whose bounding box contains the opening centre
            lo = Vector(wall.bound_box[0]) + wall.location * 0   # local->world below
            bb = [wall.matrix_world @ Vector(v) for v in wall.bound_box]
            mn = Vector((min(v.x for v in bb), min(v.y for v in bb), min(v.z for v in bb)))
            mx = Vector((max(v.x for v in bb), max(v.y for v in bb), max(v.z for v in bb)))
            if mn.x - 0.01 <= centre.x <= mx.x + 0.01 and mn.y - 0.01 <= centre.y <= mx.y + 0.01:
                cutter = box(f"cutter_{j}", centre, size, wall.users_collection[0])
                boolean_cut(wall, cutter)

def add_label(text, loc, size, coll):
    bpy.ops.object.text_add(location=loc)
    t = bpy.context.active_object
    t.data.body = text
    t.data.size = size
    t.data.align_x = t.data.align_y = 'CENTER'
    t.data.extrude = 0.0
    move_to(t, coll)
    return t

# ----------------------------------------------------------------------------
# build
# ----------------------------------------------------------------------------
clear_scene()
col2d = new_collection("2D_Floor_Plan")
col3d = new_collection("3D_Model")

mat_wall2d = make_material("wall_2d", (0.02, 0.02, 0.02, 1))
mat_wall3d = make_material("wall_3d", (0.93, 0.92, 0.88, 1))

# ---- 2D plan (flat) --------------------------------------------------------
for name, x1, y1, x2, y2, rgba in ROOMS:
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
    box("room2d_" + name, Vector((cx, cy, -0.01)) + OFFSET_2D,
        (x2 - x1, y2 - y1, 0.02), col2d, make_material("m2d_" + name, rgba))
    add_label(name, Vector((cx, cy, 0.12)) + OFFSET_2D, 0.35, col2d).data.materials.append(mat_wall2d)

walls2d = wall_boxes("plan", 0.05, 0.0, OFFSET_2D, col2d, mat_wall2d)
cut_openings(walls2d, OFFSET_2D, flat=True)

# ---- 3D model (extruded) ---------------------------------------------------
ZERO = Vector((0, 0, 0))
for name, x1, y1, x2, y2, rgba in ROOMS:                      # floor slabs, coloured per room
    box("floor_" + name, ((x1 + x2) / 2, (y1 + y2) / 2, -0.05),
        (x2 - x1, y2 - y1, 0.1), col3d, make_material("m3d_" + name, rgba))

walls3d = wall_boxes("wall3d", WALL_H, 0.0, ZERO, col3d, mat_wall3d)
cut_openings(walls3d, ZERO, flat=False)

# glass panes in the windows
glass = make_material("glass", (0.5, 0.8, 1.0, 0.35))
for j, (x, y, w, sill, top, orient, kind) in enumerate(OPENINGS):
    if kind == 'window':
        size = (w, 0.04, top - sill) if orient == 'H' else (0.04, w, top - sill)
        box(f"glass_{j}", (x, y, (sill + top) / 2), size, col3d, glass)

# ---- lighting + world ------------------------------------------------------
bpy.ops.object.light_add(type='SUN', location=(-8, -8, 14))
sun = bpy.context.active_object
sun.rotation_euler = (math.radians(50), 0, math.radians(-35))
sun.data.energy = 4
bpy.context.scene.world = bpy.data.worlds.new("World")
bpy.context.scene.world.color = (0.85, 0.9, 1.0)

# ----------------------------------------------------------------------------
# 5. CAMERAS : orthographic + perspective
# ----------------------------------------------------------------------------
def add_camera(name, loc, ortho, ortho_scale=14, target=None, rot=None):
    cam_data = bpy.data.cameras.new(name)
    cam_data.type = 'ORTHO' if ortho else 'PERSP'
    if ortho:
        cam_data.ortho_scale = ortho_scale
    cam = bpy.data.objects.new(name, cam_data)
    bpy.context.scene.collection.objects.link(cam)
    cam.location = loc
    if rot:
        cam.rotation_euler = rot
    if target:
        tr = cam.constraints.new('TRACK_TO')
        tr.target = target
        tr.track_axis, tr.up_axis = 'TRACK_NEGATIVE_Z', 'UP_Y'
    return cam

centre3d = bpy.data.objects.new("centre3d", None)
bpy.context.scene.collection.objects.link(centre3d)
centre3d.location = (5, 4, 1)

cam_plan  = add_camera("CAM_2D_Ortho_Top", (5 + OFFSET_2D.x, 4, 20), True, 13, rot=(0, 0, 0))
cam_iso   = add_camera("CAM_3D_Ortho_Iso", (17, -13, 14), True, 17, target=centre3d)
cam_persp = add_camera("CAM_3D_Perspective", (-7, -10, 8), False, target=centre3d)
cam_persp.data.lens = 28

bpy.context.scene.camera = cam_persp

# ----------------------------------------------------------------------------
# optional: render all three views to PNG (set RENDER = True)
# ----------------------------------------------------------------------------
RENDER = False
if RENDER:
    import os
    out = os.path.join(os.path.expanduser("~"), "floorplan_renders")
    os.makedirs(out, exist_ok=True)
    sc = bpy.context.scene
    sc.render.resolution_x, sc.render.resolution_y = 1600, 1000
    for cam in (cam_plan, cam_iso, cam_persp):
        sc.camera = cam
        sc.render.filepath = os.path.join(out, cam.name + ".png")
        bpy.ops.render.render(write_still=True)
    print("Renders saved to", out)

print("Done: switch views with Numpad 0 after selecting a camera "
      "(Scene > Camera, or View > Cameras > Set Active Object as Camera).")
