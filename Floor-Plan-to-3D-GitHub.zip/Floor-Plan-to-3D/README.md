# Architectural Floor Plan to 3D Visualization System

Computer Graphics micro project: converts a 2D architectural floor plan into a 3D building model and shows it with **orthographic** and **perspective** projection. Built in Blender with Python.

**Student:** Adarsh Sheetal Honawade (2411021061071)
**Guide:** Dr Shekhar R
**Department:** Computer Science and Engineering, Alliance School of Advanced Computing, Alliance University, Bengaluru

## How it works
1. The plan is described as data: walls, openings (doors/windows) and rooms, in metres.
2. A flat 2D plan is drawn (coloured rooms, labels, wall bands).
3. The same wall footprints are extruded to 3 m to make the 3D model.
4. Door and window holes are cut with Boolean modifiers; glass, light and sky are added.
5. Three cameras give the viewing modes: orthographic top, orthographic isometric, perspective.

## Run in Blender (3.x / 4.x)
1. Open Blender, go to the **Scripting** tab.
2. Open `blender_script/floorplan_to_3d.py` and click **Run Script**.
3. Select a camera in the Outliner and press **Ctrl + Numpad 0** to look through it.
4. Set `RENDER = True` at the bottom of the script to save PNG renders of all three views.

To convert a different plan, edit the `WALLS`, `OPENINGS` and `ROOMS` lists at the top of the script.

## Folder contents
| Folder | Contents |
|---|---|
| `blender_script/` | Main Blender Python script |
| `model/` | Exported OBJ/MTL 3D model and SVG 2D plan (import OBJ with Forward = Y, Up = Z) |
| `docs/` | Project report (Word) and presentation (PowerPoint) |
| `figures/` | Figures used in the report |
| `tools/` | Python scripts that export the OBJ/SVG and generate the figures (need `matplotlib`, `numpy`) |

## Notes
- The figures were generated from the exported geometry with Python, not captured from the Blender viewport.
- Limitations: axis-aligned walls only, manual data entry, no roof, stairs or furniture.
