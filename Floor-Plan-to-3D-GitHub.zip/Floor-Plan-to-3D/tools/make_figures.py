import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, numpy as np
from matplotlib.patches import Rectangle, FancyBboxPatch, FancyArrowPatch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
exec(open('export_obj_svg.py').read().split('# write OBJ')[0])   # reuse data + geometry
import collections
cols={'wall':(.93,.92,.88),'glass':(.45,.75,1.0)}
for n,*_,c in ROOMS: cols['floor_'+n.replace(' ','_')]=c
# rebuild boxes with materials
quads=[];mat=None;stats=collections.Counter()
for k,d in f:
    if k=='m': mat=d
    else: quads.append((d,mat))
stats['vertices']=len(v);stats['faces']=len(quads)
stats['boxes']=len(v)//8
print(dict(stats), collections.Counter(m for _,m in quads))
def draw3d(ax,elev,azim,proj):
    ax.set_proj_type(proj); ax.view_init(elev,azim)
    light=np.array([-.4,-.5,.8]);light/=np.linalg.norm(light)
    P=[];C=[]
    for q,m in quads:
        pts=np.array([v[i-1] for i in q],dtype=float);nrm=np.cross(pts[1]-pts[0],pts[2]-pts[1]);nrm/=np.linalg.norm(nrm)
        sh=.62+.38*max(0,nrm@light); c=np.array(cols[m])*sh
        P.append(pts);C.append((*c,.45 if m=='glass' else 1))
    pc=Poly3DCollection(P,facecolors=C,edgecolors=(.3,.3,.3,.5),linewidths=.3);ax.add_collection3d(pc)
    ax.set_xlim(-.5,10.5);ax.set_ylim(-.5,8.5);ax.set_zlim(0,3.2);ax.set_box_aspect((11,9,3.2))
    ax.set_axis_off()
def fig3d(name,elev,azim,proj,size=(8,5.2),title=None):
    fg=plt.figure(figsize=size);ax=fg.add_subplot(111,projection='3d');draw3d(ax,elev,azim,proj)
    if title: ax.set_title(title,fontsize=11)
    fg.savefig(name,dpi=260,bbox_inches='tight',facecolor='white');plt.close(fg)
fig3d("f_persp.png",38,-58,'persp',title=None)
fig3d('f_iso.png',35.264,-45,'ortho',title=None)
# 2D plan
fg,ax=plt.subplots(figsize=(8,6.6))
for n,x0,y0,x1,y1,c in ROOMS:
    ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc=c,ec='none'))
    ax.text((x0+x1)/2,(y0+y1)/2+.15,n,ha='center',fontsize=11,weight='bold',family='serif')
    ax.text((x0+x1)/2,(y0+y1)/2-.35,f'{x1-x0:g} m x {y1-y0:g} m',ha='center',fontsize=9,color='#444',family='serif')
for x1,y1,x2,y2 in WALLS: ax.plot([x1,x2],[y1,y2],'k',lw=9,solid_capstyle='projecting')
for x,y,w,_,_,o,k in OP:
    dx,dy=(w/2,0) if o=='H' else (0,w/2)
    ax.plot([x-dx,x+dx],[y-dy,y+dy],'white' if k=='door' else '#4aa3ff',lw=(9.5 if k=='door' else 4),solid_capstyle='butt',zorder=5)
    if k=='door':
        r=w; 
        from matplotlib.patches import Arc
        if o=='H': ax.add_patch(Arc((x-w/2,y),2*r,2*r,theta1=0,theta2=90,ec='k',lw=.8,zorder=6)); ax.plot([x-w/2,x-w/2],[y,y+r],'k',lw=.8,zorder=6)
        else: ax.add_patch(Arc((x,y-w/2),2*r,2*r,theta1=0,theta2=90,ec='k',lw=.8,zorder=6)); ax.plot([x,x+r],[y-w/2,y-w/2],'k',lw=.8,zorder=6)
for i in range(0,11,2): ax.text(i,-.9,f'{i}',ha='center',fontsize=8)
for j in range(0,9,2): ax.text(-.9,j,f'{j}',va='center',fontsize=8)
ax.set_xlim(-1.3,11.3);ax.set_ylim(-1.5,9.2);ax.set_aspect('equal');ax.axis('off')
ax.plot([0,0],[-1.15,-1.15]);ax.text(5,-1.35,'metres',ha='center',fontsize=8)
fg.savefig('f_plan2d.png',dpi=260,bbox_inches='tight',facecolor='white');plt.close(fg)
# top & front ortho
fig3d('f_top.png',90,-90,'ortho',size=(6,5))
fg=plt.figure(figsize=(6,3));ax=fg.add_subplot(111,projection='3d');draw3d(ax,0,-90,'ortho');fg.savefig('f_front.png',dpi=260,bbox_inches='tight',facecolor='white');plt.close(fg)
# diagrams
def flow(name,labels,w=3.2,h=.62,gap=.42,decision=None,figw=4):
    n=len(labels);fg,ax=plt.subplots(figsize=(figw,(h+gap)*n+.2));ax.set_xlim(0,w+.4);ax.set_ylim(0,(h+gap)*n);ax.axis('off')
    for i,l in enumerate(labels):
        y=(h+gap)*(n-1-i)
        ax.add_patch(FancyBboxPatch((.2,y),w,h,boxstyle='round,pad=0.02,rounding_size=.1',fc='#eaf1fb' if i not in (0,n-1) else '#d9ead3',ec='#333',lw=1))
        ax.text(.2+w/2,y+h/2,l,ha='center',va='center',fontsize=8.5,family='serif')
        if i<n-1: ax.add_patch(FancyArrowPatch((.2+w/2,y),(.2+w/2,y-gap),arrowstyle='-|>',mutation_scale=10,color='#333'))
    fg.savefig(name,dpi=260,bbox_inches='tight',facecolor='white');plt.close(fg)
flow('f_flow_main.png',['Start: clear scene, create\ncollections and materials','Read WALLS, OPENINGS and\nROOMS data lists','Build 2D plan: room planes,\nlabels, flat wall footprints','Cut door/window gaps in the\nflat walls (Boolean)','Build 3D model: floor slabs and\nwalls extruded to 3 m','Cut door/window holes in the\n3D walls (Boolean)','Add glass panes, sun light\nand world colour','Create three cameras:\n2D top, 3D iso, 3D perspective','End: export OBJ/SVG or\nrender PNG images'],figw=4.2)
flow('f_flow_cut.png',['For each opening j in OPENINGS','Compute cutter box from\nposition, width, sill and top','For each wall: does its bounding\nbox contain the opening centre?','If yes: add Boolean DIFFERENCE\nmodifier using the cutter','Apply modifier and delete cutter'],figw=3.8)
# architecture / pipeline horizontal
fg,ax=plt.subplots(figsize=(9,2.6));ax.set_xlim(0,9);ax.set_ylim(0,2.6);ax.axis('off')
st=[('Plan data','walls, openings,\nrooms (metres)'),('2D plan','flat footprints,\nrooms, labels'),('Extrusion','walls raised to\n3 m, floor slabs'),('Boolean cuts','door and window\nopenings'),('Cameras','orthographic and\nperspective'),('Output','viewport, PNG,\nOBJ, SVG')]
for i,(a,b) in enumerate(st):
    x=.1+i*1.48
    ax.add_patch(FancyBboxPatch((x,.7),1.2,1.3,boxstyle='round,pad=0.02,rounding_size=.08',fc='#eaf1fb',ec='#333'))
    ax.text(x+.6,1.7,a,ha='center',weight='bold',fontsize=8.5,family='serif');ax.text(x+.6,1.15,b,ha='center',va='center',fontsize=7.5,family='serif')
    if i<5: ax.add_patch(FancyArrowPatch((x+1.2,1.35),(x+1.48,1.35),arrowstyle='-|>',mutation_scale=10))
fg.savefig('f_arch.png',dpi=260,bbox_inches='tight',facecolor='white');plt.close(fg)
# frustum vs box (ortho vs persp concept)
fg,(a,b)=plt.subplots(1,2,figsize=(8,3))
for ax,t,kind in ((a,'Orthographic: parallel projectors','o'),(b,'Perspective: projectors meet at the eye','p')):
    ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis('off');ax.set_title(t,fontsize=10,family='serif')
    ax.plot([8.5,8.5],[.5,5.5],'k',lw=2);ax.text(8.5,.1,'image plane',ha='center',fontsize=8)
    ax.add_patch(Rectangle((2,2.2),1.2,1.6,fc='#f5d7a1',ec='k'));ax.add_patch(Rectangle((5,2.4),1.2,1.2,fc='#f5d7a1',ec='k'))
    if kind=='o':
        for y in (2.2,3.8): ax.plot([2,8.5],[y,y],'r--',lw=1)
        for y in (2.4,3.6): ax.plot([5,8.5],[y,y],'b--',lw=1)
    else:
        ax.plot(0.6,3,'ko');ax.text(.6,2.5,'eye',ha='center',fontsize=8)
        for y in (2.2,3.8): ax.plot([.6,8.5],[3,3+(y-3)*(8.5-.6)/(2-.6)],'r--',lw=1)
        for y in (2.4,3.6): ax.plot([.6,8.5],[3,3+(y-3)*(8.5-.6)/(5-.6)],'b--',lw=1)
fg.savefig('f_projections.png',dpi=260,bbox_inches='tight',facecolor='white');plt.close(fg)
