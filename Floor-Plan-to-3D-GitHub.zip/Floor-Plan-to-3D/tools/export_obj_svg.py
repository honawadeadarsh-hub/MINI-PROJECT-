T,H=0.2,3.0
WALLS=[(0,0,10,0),(10,0,10,8),(10,8,0,8),(0,8,0,0),(6,0,6,5),(0,5,10,5),(5,5,5,8)]
OP=[(3,0,1,0,2.1,'H','door'),(8,0,1.5,.9,2.1,'H','window'),(0,2.5,1.5,.9,2.1,'V','window'),
(10,2.5,1.5,.9,2.1,'V','window'),(6,2.5,1.2,0,2.1,'V','door'),(3,5,.9,0,2.1,'H','door'),
(8,5,.9,0,2.1,'H','door'),(2.5,8,1.5,.9,2.1,'H','window'),(7.5,8,1,.9,2.1,'H','window')]
ROOMS=[("LIVING ROOM",0,0,6,5,(.8,.9,1)),("KITCHEN",6,0,10,5,(1,.92,.7)),("BEDROOM",0,5,5,8,(.85,1,.85)),("BATHROOM",5,5,10,8,(.95,.85,1))]
v=[];f=[];cur=[None]
def box(x0,x1,y0,y1,z0,z1,m):
    if x1-x0<1e-6 or y1-y0<1e-6 or z1-z0<1e-6: return
    b=len(v)
    v.extend([(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)])
    if cur[0]!=m: f.append(('m',m)); cur[0]=m
    for q in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:
        f.append(('f',[b+i+1 for i in q]))
# floors
for n,x0,y0,x1,y1,c in ROOMS: box(x0,x1,y0,y1,-0.1,0,'floor_'+n.replace(' ','_'))
# walls with real openings
for x1,y1,x2,y2 in WALLS:
    hor=abs(y2-y1)<1e-6
    if hor:
        a0,a1=min(x1,x2),max(x1,x2); c=y1
        ops=sorted([o for o in OP if o[5]=='H' and abs(o[1]-c)<1e-6 and a0<=o[0]<=a1],key=lambda o:o[0]); pos=lambda o:o[0]
    else:
        a0,a1=min(y1,y2),max(y1,y2); c=x1
        ops=sorted([o for o in OP if o[5]=='V' and abs(o[0]-c)<1e-6 and a0<=o[1]<=a1],key=lambda o:o[1]); pos=lambda o:o[1]
    def seg(s,e,z0,z1,m):
        if hor: box(s,e,c-T/2,c+T/2,z0,z1,m)
        else: box(c-T/2,c+T/2,s,e,z0,z1,m)
    s=a0-T/2
    for o in ops:
        w=o[2]; p=pos(o)
        seg(s,p-w/2,0,H,'wall'); s=p+w/2
        seg(p-w/2,p+w/2,0,o[3],'wall'); seg(p-w/2,p+w/2,o[4],H,'wall')
        if o[6]=='window':
            g=0.03
            if hor: box(p-w/2,p+w/2,c-g,c+g,o[3],o[4],'glass')
            else: box(c-g,c+g,p-w/2,p+w/2,o[3],o[4],'glass')
    seg(s,a1+T/2,0,H,'wall')
# write OBJ (Z-up; Blender import: set Forward=Y, Up=Z)
with open('floorplan_3d.obj','w') as o:
    o.write('mtllib floorplan_3d.mtl\n')
    for p in v:o.write('v %.4f %.4f %.4f\n'%p)
    for k,d in f:
        o.write(('usemtl %s\n'%d) if k=='m' else 'f '+' '.join(map(str,d))+'\n')
with open('floorplan_3d.mtl','w') as o:
    o.write('newmtl wall\nKd 0.93 0.92 0.88\n\nnewmtl glass\nKd 0.5 0.8 1.0\nd 0.35\n\n')
    for n,*_,c in ROOMS: o.write('newmtl floor_%s\nKd %s %s %s\n\n'%(n.replace(' ','_'),*c))
# 2D SVG
S=60;P=40;W=10*S+2*P;Hh=8*S+2*P
X=lambda x:P+x*S; Y=lambda y:P+(8-y)*S
s=['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d"><rect width="100%%" height="100%%" fill="white"/>'%(W,Hh,W,Hh)]
for n,x0,y0,x1,y1,c in ROOMS:
    col='rgb(%d,%d,%d)'%tuple(int(i*255) for i in c)
    s.append('<rect x="%g" y="%g" width="%g" height="%g" fill="%s"/>'%(X(x0),Y(y1),(x1-x0)*S,(y1-y0)*S,col))
    s.append('<text x="%g" y="%g" font-family="Arial" font-size="15" font-weight="bold" text-anchor="middle">%s</text>'%(X((x0+x1)/2),Y((y0+y1)/2),n))
    s.append('<text x="%g" y="%g" font-family="Arial" font-size="11" text-anchor="middle" fill="#444">%gm x %gm</text>'%(X((x0+x1)/2),Y((y0+y1)/2)+16,x1-x0,y1-y0))
for x1,y1,x2,y2 in WALLS: s.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="black" stroke-width="%g" stroke-linecap="square"/>'%(X(x1),Y(y1),X(x2),Y(y2),T*S))
for x,y,w,_,_,ori,k in OP:
    dx,dy=(w/2,0) if ori=='H' else (0,w/2)
    col='white' if k=='door' else '#4aa3ff'
    s.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="%g"/>'%(X(x-dx),Y(y-dy),X(x+dx),Y(y+dy),col,T*S*(1.05 if k=='door' else .5)))
s.append('<text x="%d" y="22" font-family="Arial" font-size="16" font-weight="bold">2D FLOOR PLAN (white gap = door, blue = window)</text></svg>'%P)
open('floorplan_2d.svg','w').write('\n'.join(s))
